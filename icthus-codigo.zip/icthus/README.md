# Icthus · v0.4

Aplicación web en español para buscar versículos, guardar cantos y proyectar contenido desde una Chromebook hacia una pantalla de iglesia. Usa HTML, CSS y JavaScript, sin dependencias de ejecución.

## Cantos por partes

1. Abre **Cantos → Agregar**, escribe el título y añade partes con **+ Verso**, **+ Coro**, **+ Precoro** o **+ Puente**. El selector de cada bloque también ofrece Intro, Final, Instrumental y Otra parte. Escribe o pega la letra de cada bloque.
2. Si ya tienes la letra completa, abre **¿Ya tienes la letra completa?**, pégala y pulsa **Convertir en partes**. Las líneas vacías separan las partes y se reconocen encabezados independientes como `[Coro]`, `Verso 1`, `Precoro` y `Puente`. Las etiquetas se muestran al operador, no se añaden a la letra proyectada. Revisa el tipo de cada bloque antes de guardar.
3. En **Orden al proyectar**, agrega una misma parte varias veces para secuencias como Verso 1, Coro, Verso 2, Coro. **Antes**, **Después** y **Quitar** cambian los pasos; **Usar el orden de las partes** recupera la secuencia original. La letra de un coro repetido se edita una sola vez.
4. Guarda el canto. Al seleccionarlo aparece su **panel de partes** con una tarjeta por paso. Pulsar una tarjeta prepara la vista previa; su botón **Proyectar** la envía directamente a la salida. Las flechas avanzan por las pantallas siguiendo el orden guardado. Se distingue la parte en vista previa de la que está en proyección, incluida la pantalla negra.

Los bloques largos se dividen en varias pantallas antes de avanzar a la siguiente parte. El panel informa cuántas pantallas tiene cada parte. Se admiten hasta 100 partes y 200 pasos por canto, 50,000 caracteres de letra y un máximo de 2,000 pantallas en un orden.

Los cantos anteriores se adaptan conservando su identificador, letra y separación de estrofas. Las partes sin etiqueta se muestran como versos; puedes cambiar su tipo en **Editar partes**. El ejemplo nuevo incluye un coro y su repetición.

Los borradores conservan las etiquetas, partes sin terminar, orden y letra pendiente de convertir. El respaldo JSON `icthus-cantos-v2` conserva las partes y las repeticiones; se siguen admitiendo TXT, listas JSON y respaldos `ap-cantos-v1`. Los favoritos y el historial guardan también la identidad de la parte para recuperarla después de reordenar un canto.

## Fondos, tipografía y transiciones

**Diseño de pantalla** contiene tres pestañas. Los ajustes se aplican a la vista previa y a la salida y se conservan en el navegador.

- **Fondos:** ocho diseños (Índigo, Negro, Océano, Bosque, Atardecer, Vino, Aurora y Grafito), color sólido a elección e imagen propia JPG, PNG o WebP. El control de oscuridad permite mejorar el contraste. La última imagen elegida se guarda en IndexedDB local; no se sube al servidor ni se incluye en el código descargable. Se prepara una copia de hasta 1920 × 1080, conservando proporciones, para proyectar con menor consumo de memoria. El archivo original permanece en tu equipo.
- **Texto:** cinco familias de letra; tamaño base entre 20 y 160, con deslizador y campo numérico; color, negrita, cursiva y mayúsculas; alineación horizontal y posición vertical. **Más opciones** permite ajustar interlineado, separación de letras, márgenes, sombra, contorno, tamaño de referencia y visibilidad de referencia y versión.
- **Ajustar para que quepa** reduce la letra cuando el texto excede el espacio disponible. La vista previa informa el tamaño efectivo. Al desactivarlo se respeta el tamaño manual y se avisa si hay desbordamiento. El tamaño base se adapta a la resolución de la pantalla.
- **Transición:** corte, fundido suave o desplazamiento suave. La duración es configurable entre 0.1 y 1.5 segundos; el valor predeterminado es un fundido de 0.4 segundos. La preferencia de movimiento reducido del equipo se respeta.
- La pantalla negra se activa inmediatamente. Los cambios rápidos reemplazan la transición pendiente y mantienen un máximo de dos capas. Los mensajes repetidos de conexión no vuelven a dibujar ni animar el mismo contenido.
- **Restablecer texto** recupera la tipografía inicial, conservando el fondo y la transición.

## Usarla durante el culto

1. Abre Icthus en Chrome con internet y espera «Lista sin conexión» para descargar el contenido incluido.
2. Conecta la segunda pantalla. En Configuración → Dispositivo → Pantallas, desactiva la duplicación.
3. Pulsa **Abrir proyección**, mueve esa ventana a la pantalla de la iglesia y activa **Pantalla completa**.
4. Busca una referencia o palabras, elige contenido y pulsa **Proyectar**. La vista previa es independiente de la salida.
5. En **Cantos**, agrega o importa tus letras y elige sus partes. **Respaldar** descarga tus cantos, etiquetas y orden como JSON.

Las flechas cambian las diapositivas de la salida; B activa o quita la pantalla negra. Los atajos no actúan mientras escribes. Enter envía la vista previa cuando no hay un botón o campo enfocado; los botones conservan su propia función al recibir Enter.

## Historial y favoritos

- **Historial** conserva los últimos 60 contenidos enviados a proyección. Avanzar en la salida también registra el contenido. Volver a proyectar un elemento lo coloca al principio sin duplicarlo.
- La estrella junto a **Proyectar** guarda hasta 100 favoritos de versículos, cantos o mensajes.
- Las referencias guardan su edición: una cita de RV1909 y la misma cita de otra edición son favoritos diferentes.
- Recuperar contenido lo prepara en la vista previa. La salida conserva su contenido hasta pulsar **Proyectar**.
- Los cantos se recuperan de la biblioteca actual, en la estrofa guardada. Si se eliminó un canto, se conserva la última diapositiva registrada en el historial o favorito.

## Borradores automáticos

Los anuncios y cantos pendientes se guardan localmente tras una breve pausa. También se fuerza el guardado al cerrar el editor, recargar, salir o pasar la pestaña a segundo plano.

- El anuncio vuelve a sus campos al abrir Icthus.
- Los cantos se retoman en **Cantos → Borradores guardados**. Hay un borrador para un canto nuevo y uno por cada canto que estés editando, hasta 25.
- Cerrar el editor conserva el borrador. **Descartar borrador** lo elimina sin modificar el canto de la biblioteca.
- **Guardar canto** actualiza la biblioteca y elimina su borrador.
- Los mensajes distinguen guardado exitoso de falta de espacio. Si no se pudo guardar, el formulario conserva el texto y muestra el error.

## Selector de versión bíblica

La descarga incluye únicamente **Reina-Valera 1909**, de dominio público. **RVR1960 y TLA están pendientes de activar**: sus textos completos no se incluyen ni se descargan de fuentes no autorizadas.

Para usar un archivo autorizado de **Reina-Valera 1960** o **Traducción en Lenguaje Actual**, abre **Gestionar versiones**, selecciona la edición y elige **Archivo de tu equipo** o **Enlace al archivo JSON**. La descarga por enlace HTTPS solo ocurre al pulsar **Importar versión**, sin enviar cookies ni datos de acceso al servidor de origen. Si el servidor impide la descarga, se puede guardar el JSON e importarlo como archivo. El máximo es 15 MB. Las versiones importadas se guardan en IndexedDB del navegador, con su identificación y aviso de derechos. No se suben al servidor ni se incluyen en el código descargable. Cerrar el diálogo cancela una descarga pendiente.

Se admiten objetos con `books`, códigos como `GEN`, `EXO`, `JHN`, etc., arreglos de capítulos y arreglos de textos de versículos. También se admiten arreglos de libros con `chapters`, incluidos los formatos con `name`, `chapter` y `verses` numerados de Scrollmapper, y el formato Snapshots con `usfm`, `human`, `items`, `verse_numbers` y `lines`. En Snapshots se excluyen los títulos, se reúnen los bloques consecutivos de un mismo versículo respetando sus líneas y se omite un capítulo repetido únicamente si sus bloques son exactamente iguales. Un capítulo repetido con diferencias se rechaza. Se conservan `copyright.text` y las identificaciones `local_abbreviation` / `local_title` para comprobar la edición; no se usa ni se ejecuta el HTML del archivo.

El importador comprueba los 66 libros, sus capítulos, numeración y versículos vacíos. Rechaza cambiar una edición identificada como RV1909 por la etiqueta de RVR1960 o TLA. Los formatos con versículos combinados o numeración discontinua necesitan una conversión revisada; no se renumeran automáticamente.

Seleccionar una edición pendiente abre la importación y conserva la edición activa. Cada diapositiva muestra el nombre de la edición cuyo texto se está usando. Información: [Sociedades Bíblicas Unidas](https://ubscopyrights.org/index.php/pages/view/rules).

## Datos incluidos y almacenamiento

- Biblia **RV1909**, con ortografía y numeración de la fuente. No es RV1960. Fuente: [eBible.org](https://ebible.org/find/details.php?id=spaRV1909). Procedencia y SHA-256 en `dist/data/FUENTE.txt`.
- Se omiten 18 registros de relleno vacíos al final de algunos capítulos del VPL, conservando el texto y su numeración. Quedan 31,084 registros con contenido. Algunas referencias difieren de otras ediciones.
- El canto inicial es una letra original de ejemplo. Las búsquedas consultan la biblioteca que tú agregues.
- Cantos, favoritos, historial y borradores se guardan en este navegador y equipo; no se sincronizan. **Respaldar** conserva una copia de los cantos.
- Se mantienen las claves de almacenamiento anteriores al cambio de nombre para conservar cantos y preferencias existentes.
- El panel y la salida se comunican mediante BroadcastChannel, postMessage y eventos de almacenamiento en el mismo navegador y origen. Mantén abierto el panel.
- La ventana se mueve a la segunda pantalla manualmente. «Salida conectada» confirma comunicación con esa ventana, no comprueba el cable físico.
- El sitio conserva su identidad, dirección y acceso privado de propietario.
- El modo sin conexión requiere una descarga inicial completa. Las versiones importadas siguen disponibles en el mismo navegador mientras no se borren sus datos.
- Se conserva la corrección de `ERR_FAILED`: las navegaciones no reciben respuestas almacenadas marcadas como ya redirigidas.

## Aprender a programarla

- `dist/index.html`: estructura y botones.
- `dist/styles.css`: diseño adaptable y fondos.
- `dist/app.js`: interfaz, búsquedas y controles.
- `dist/core.js`: referencias y división de diapositivas.
- `dist/songs.js`: partes de cantos, importación, migración y orden de proyección.
- `dist/personal-library.js`: historial, favoritos y borradores.
- `dist/versions.js`: identificación, importación y persistencia de Biblias.
- `dist/bible-download.js`: descarga voluntaria de JSON por HTTPS con límite de tamaño y cancelación.
- `dist/renderer.js`: ajusta y dibuja el texto.
- `dist/appearance.js`: valida estilos, fondos y parámetros de transición.
- `dist/background-media.js`: prepara y guarda la imagen elegida en el navegador.
- `dist/projection.html` y `dist/projection.js`: ventana de salida.
- `dist/sw.js`: archivos para uso sin conexión.
- `tests/`: integridad bíblica, referencias, importación, colecciones, borradores y regresión de redirecciones.

Para probar con Python:

```bash
python3 -m http.server 8000 --directory dist
```

Abre `http://localhost:8000` en Chrome. Un servidor local permite cargar los módulos y activar el modo sin conexión.

Para ejecutar las pruebas con Node.js, sin instalar paquetes:

```bash
npm test
```

`python3 scripts/package-code.py` prepara `dist/icthus-codigo.zip`, excluyendo Git, la identidad del sitio y los datos del navegador. Tras cambiar la aplicación, cambia `CACHE` en `dist/sw.js` para actualizar la copia local. En Chrome, Ctrl + Mayús + R fuerza la recarga al estrenar una versión.

## v0.5 · Instalación independiente y copias completas

**Aplicación** permite instalar Icthus desde Chrome y trasladar cantos, favoritos, historial, borradores y ajustes en un JSON revisado antes de restaurar. La restauración conserva los identificadores de cantos y partes, y revierte las escrituras si falta espacio. Las Biblias e imágenes se reimportan por separado. No hay cuenta ni servidor para guardar datos personales.

El manifiesto incluye iconos PNG de 192 y 512 píxeles y rutas relativas para GitHub Pages. El caché sin conexión se separa por ruta del proyecto para no borrar otras aplicaciones del mismo dominio. El botón de instalación solo se habilita cuando Chrome entrega su aviso real; siempre hay instrucciones para el menú.

Guía: [Instalar Icthus](docs/INSTALAR-ICTHUS.md). `python3 scripts/package-code.py` prepara el código para estudiar; `python3 scripts/package-independent.py` prepara el alojamiento estático con `.nojekyll`. Los iconos se regeneran con `scripts/build-icons.py` y Pillow. `dist/backup.js` valida las copias y `dist/install.js` gestiona la instalación. Ningún paquete incluye `.openai`, Git, credenciales ni datos del navegador.

## v0.6 · Modo claro y oscuro

El botón de sol o luna de la cabecera cambia la apariencia del panel y conserva la preferencia en `icthus-color-mode-v1`. `dist/color-mode.js` aplica el modo antes de cargar los estilos, lo sincroniza entre pestañas y recupera el modo oscuro si el almacenamiento no está disponible. `dist/color-mode.css` contiene los colores de la interfaz; las diapositivas usan sus ajustes de proyección.
