import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const manifest=JSON.parse(readFileSync(new URL('../dist/manifest.webmanifest',import.meta.url)));
test('Chrome recibe un manifiesto instalable con iconos PNG de tamaño real',()=>{
  assert.equal(manifest.name,'Icthus');assert.equal(manifest.display,'standalone');
  for(const size of [192,512]){
    const icon=manifest.icons.find(item=>item.sizes===`${size}x${size}`);assert.ok(icon);assert.equal(icon.type,'image/png');
    const bytes=readFileSync(new URL('../dist/'+icon.src,import.meta.url));assert.equal(bytes.toString('hex',0,8),'89504e470d0a1a0a');assert.equal(bytes.readUInt32BE(16),size);assert.equal(bytes.readUInt32BE(20),size);
  }
});
test('el inicio, la identidad y los iconos conservan la subcarpeta de GitHub Pages',()=>{
  const base='https://example.github.io/icthus/manifest.webmanifest';
  for(const relative of [manifest.id,manifest.scope,manifest.start_url,...manifest.icons.map(item=>item.src)])assert.ok(new URL(relative,base).pathname.startsWith('/icthus/'));
});
