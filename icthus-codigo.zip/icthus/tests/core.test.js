import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {BOOKS,normalize,parseReference,resolveReference,buildSearchIndex,searchVerses,splitText,textSlides,verseSlides,validateSongs,safeProjection} from '../dist/core.js';
const bible=JSON.parse(readFileSync(new URL('../dist/data/rv1909.json',import.meta.url)));
const index=buildSearchIndex(bible);
test('carga íntegra: 66 libros, todos los registros con texto de la fuente y sin libros desconocidos',()=>{
  assert.equal(Object.keys(bible.books).length,66);assert.equal(index.length,31084);
  assert.deepEqual(Object.keys(bible.books).sort(),BOOKS.map(b=>b.id).sort());
  assert.ok(index.every(row=>row.text.trim()));
});
test('referencias con tildes, abreviaturas, libros numerados y rangos',()=>{
  for(const query of ['Juan 3:16','Jn3:16','Jua. 3:16']){const r=parseReference(query);assert.equal(r.book.id,'JHN');assert.equal(r.chapter,3);assert.equal(r.first,16);}
  assert.equal(parseReference('1 Juan 4:8').book.id,'1JN');
  assert.equal(parseReference('2Timoteo 3:16').book.id,'2TI');
  assert.equal(parseReference('Génesis 1:1').book.id,'GEN');
  assert.equal(parseReference('Salmo 23').book.id,'PSA');
  assert.equal(parseReference('Romanos 8:28–30').last,30);
  assert.equal(parseReference('por nada esteis afanosos'),null);
});
test('no inventa referencias inexistentes ni rangos invertidos',()=>{
  for(const query of ['Juan 0','Juan 99','Juan 3:0','Juan 3:999','Juan 3:18-16'])assert.throws(()=>resolveReference(parseReference(query),bible));
  assert.equal(resolveReference(parseReference('Salmos 119'),bible).length,176);
  assert.throws(()=>resolveReference(parseReference('2 Corintios 13:14'),bible)); // El VPL de esta edición termina el capítulo en el v. 13.
});
test('texto literal del archivo fuente y búsqueda sin tildes',()=>{
  const rows=resolveReference(parseReference('Juan 3:16'),bible);
  assert.equal(rows[15].text,bible.books.JHN[2][15]);
  assert.ok(rows[15].text.startsWith('Porque de tal manera amó Dios al mundo'));
  assert.ok(searchVerses('por nada esteis afanosos',index).results.some(r=>r.reference==='Filipenses 4:6'));
  const search=searchVerses('Dios',index,7);assert.equal(search.results.length,7);assert.ok(search.total>7);
  assert.equal(normalize('  AMÓ   Díos! '),'amo dios');
});
test('dividir textos largos conserva todas las palabras y referencias',()=>{
  const text=('Un mensaje largo que debe conservarse completo. ').repeat(40);
  const chunks=splitText(text,90);assert.ok(chunks.every(p=>p.length<=90));assert.equal(chunks.join(' '),text.trim());
  const slides=verseSlides([{text,reference:'Prueba 1:1'}]);assert.ok(slides.length>1);assert.ok(slides.every(s=>s.key==='Prueba 1:1'));
  const stanzas=textSlides('Primera línea\nSegunda línea\n\nCoro\nOtro renglón','Mi canto');assert.equal(stanzas.length,2);assert.equal(stanzas[0].text,'Primera línea\nSegunda línea');
});
test('respaldo de cantos valida formato y regenera identificadores',()=>{
  const songs=validateSongs({schema:'ap-cantos-v1',songs:[{id:'old',title:'  Mi canto  ',lyrics:' Una estrofa '}]});
  assert.equal(songs[0].title,'Mi canto');assert.notEqual(songs[0].id,'old');
  assert.throws(()=>validateSongs({songs:[]}));assert.throws(()=>validateSongs([{title:' ',lyrics:'test'}]));assert.throws(()=>validateSongs([{title:'test',lyrics:null}]));
});
test('mensajes de proyección corruptos no rompen la pantalla',()=>{
  assert.equal(safeProjection({slides:[{}]}),null);
  const value=safeProjection({slides:[{text:'Hola',reference:'Anuncio',version:''}],index:500,theme:'bad',fontSize:999});
  assert.equal(value.index,0);assert.equal(value.theme,'indigo');assert.equal(value.fontSize,160);
});
