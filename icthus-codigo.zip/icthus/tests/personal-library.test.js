import test from 'node:test';
import assert from 'node:assert/strict';
import {contentEntry,addToHistory,toggleFavorite,cleanEntries,emptyDrafts,cleanDrafts,savePersonal,PERSONAL_KEYS} from '../dist/personal-library.js';
const slide={text:'Texto de prueba',reference:'Juan 3:16',key:'Juan 3:16',version:'Reina-Valera 1909'};
const makeEntry=(versionId='RV1909',now=1000)=>contentEntry({...slide,version:versionId},{kind:'bible',versionId},0,now);

test('los favoritos de una misma cita en versiones distintas se conservan por separado',()=>{
  const one=makeEntry('RV1909'),two=makeEntry('RVR1960');
  let favorites=toggleFavorite([],one);favorites=toggleFavorite(favorites,two);
  assert.equal(favorites.length,2);assert.notEqual(one.id,two.id);
  favorites=toggleFavorite(favorites,one);assert.equal(favorites.length,1);assert.equal(favorites[0].source.versionId,'RVR1960');
});
test('el historial actualiza la posición, elimina duplicados y conserva solo 60 entradas',()=>{
  let history=[];
  for(let index=1;index<=75;index++)history=addToHistory(history,contentEntry({...slide,reference:`Juan 3:${index}`,key:`Juan 3:${index}`},{kind:'bible',versionId:'RV1909'},0,index));
  assert.equal(history.length,60);assert.equal(history[0].title,'Juan 3:75');
  const again={...history[20],usedAt:9000};history=addToHistory(history,again);
  assert.equal(history.length,60);assert.equal(history[0].usedAt,9000);assert.equal(new Set(history.map(item=>item.id)).size,60);
});
test('un canto favorito conserva el identificador y la última estrofa, sin duplicarse',()=>{
  const first=contentEntry({...slide,reference:'Mi canto',version:''},{kind:'song',songId:'song-1'},0,1000);
  const second=contentEntry({...slide,text:'Segunda estrofa',reference:'Mi canto',version:''},{kind:'song',songId:'song-1'},2,2000);
  const history=addToHistory([first],second);assert.equal(history.length,1);assert.equal(history[0].source.index,2);assert.equal(history[0].slide.text,'Segunda estrofa');
});
test('los mensajes de texto tienen una identidad estable y conservan su contenido',()=>{
  const one=contentEntry({...slide,reference:'Anuncio',version:''},{kind:'text'});
  const same=contentEntry({...slide,reference:'Anuncio',version:''},{kind:'text'});
  const other=contentEntry({...slide,text:'Otro texto',reference:'Anuncio',version:''},{kind:'text'});
  assert.equal(one.id,same.id);assert.notEqual(one.id,other.id);assert.deepEqual(one.slide.text,slide.text);
});
test('las colecciones descartan datos corruptos y rechazan fechas que no pueden mostrarse',()=>{
  assert.equal(cleanEntries([null,{},makeEntry(),{...makeEntry(),usedAt:1e100}]).length,1);
  assert.throws(()=>toggleFavorite(Array.from({length:100},(_,i)=>({...makeEntry(),id:'id-'+i})),makeEntry()),/100/);
});
test('se recuperan borradores de anuncios, cantos nuevos y ediciones sin afectar la canción guardada',()=>{
  const value={...emptyDrafts(),text:{title:'Anuncio',text:'Mensaje sin terminar',updatedAt:100},songs:{new:{songId:null,title:'Canto nuevo',lyrics:'Primera línea\nOtra línea',updatedAt:101},saved:{songId:'saved',title:'Canto editado',lyrics:'Cambio pendiente',updatedAt:102}}};
  const recovered=cleanDrafts(JSON.parse(JSON.stringify(value)));
  assert.deepEqual(recovered,value);assert.equal(cleanDrafts({bad:true}).text,null);
  assert.equal(Object.keys(cleanDrafts({...value,songs:{broken:{lyrics:123}}}).songs).length,0);
});
test('la escritura es recuperable tras recargar y los errores de espacio no se presentan como guardado',()=>{
  const memory=new Map(),storage={setItem:(key,value)=>memory.set(key,value)};
  const draft={...emptyDrafts(),text:{title:'',text:'Última pulsación',updatedAt:100}};
  savePersonal(storage,PERSONAL_KEYS.drafts,draft);
  assert.equal(cleanDrafts(JSON.parse(memory.get(PERSONAL_KEYS.drafts))).text.text,'Última pulsación');
  assert.throws(()=>savePersonal({setItem(){throw new Error('QuotaExceededError');}},PERSONAL_KEYS.drafts,draft),/No se pudo guardar/);
});
