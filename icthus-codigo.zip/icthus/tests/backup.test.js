import test from 'node:test';
import assert from 'node:assert/strict';
import {createDataBackup,parseDataBackup,restoreDataBackup,APP_DATA_KEYS} from '../dist/backup.js';
import {contentEntry,emptyDrafts} from '../dist/personal-library.js';
const song={id:'song-1',title:'Prueba original',sections:[{id:'v1',type:'verse',text:'Verso de prueba'},{id:'c',type:'chorus',text:'Coro de prueba'}],order:['v1','c','c']};
function sample(){
  const favorite=contentEntry({text:'Coro de prueba',reference:song.title,version:'',songSectionId:'c',songPartPage:0,songStep:2},{kind:'song',songId:song.id},2,1000);
  return createDataBackup({songs:[song],favorites:[favorite],history:[favorite],settings:{textStyle:{fontSize:72},versionId:'RVR1960'},drafts:{...emptyDrafts(),songs:{new:{songId:null,title:'Sin terminar',lyrics:'Otra línea',sections:[{id:'x',type:'prechorus',text:'Otra línea'}],order:['x','x'],updatedAt:1000}}}});
}
function storage(){const map=new Map();return {map,getItem:key=>map.get(key)??null,setItem:(key,value)=>map.set(key,value),removeItem:key=>map.delete(key)};}

test('la copia conserva partes, orden, identificadores, favoritos, ajustes y borradores',()=>{
  const backup=parseDataBackup(JSON.parse(JSON.stringify(sample()))),d=backup.data;
  assert.equal(d.songs[0].id,song.id);assert.deepEqual(d.songs[0].order,['v1','c','c']);
  assert.equal(d.favorites[0].source.songId,song.id);assert.equal(d.favorites[0].source.sectionId,'c');
  assert.deepEqual(d.drafts.songs.new.order,['x','x']);assert.equal(d.settings.textStyle.fontSize,72);
  assert.equal(d.settings.versionId,'RVR1960');assert.deepEqual(Object.keys(d),['songs','settings','history','favorites','drafts']);
});
test('restaurar sustituye solo las cinco colecciones de Icthus',()=>{
  const target=storage();target.setItem('unrelated','safe');restoreDataBackup(target,sample());
  assert.equal(target.getItem('unrelated'),'safe');assert.equal(JSON.parse(target.getItem(APP_DATA_KEYS.songs))[0].id,song.id);
  assert.equal(target.map.size,6);
});
test('un fallo de escritura recupera todos los valores anteriores incluso los ausentes',()=>{
  const target=storage();target.setItem(APP_DATA_KEYS.songs,'previous');target.setItem('unrelated','safe');
  const set=target.setItem;let failed=false;target.setItem=(key,value)=>{if(key===APP_DATA_KEYS.history&&!failed){failed=true;throw Error('quota');}return set(key,value);};
  assert.throws(()=>restoreDataBackup(target,sample()),/anteriores se conservaron/);
  assert.deepEqual([...target.map],[['ap-songs-v1','previous'],['unrelated','safe']]);
});
test('una copia corrupta o con identificadores repetidos se rechaza antes de escribir',()=>{
  const backup=sample();backup.data.songs.push(backup.data.songs[0]);assert.throws(()=>parseDataBackup(backup));
  const broken=sample();broken.data.drafts.songs.new.order=['missing'];assert.throws(()=>parseDataBackup(broken));
  assert.throws(()=>parseDataBackup({schema:'otro'}));
});
