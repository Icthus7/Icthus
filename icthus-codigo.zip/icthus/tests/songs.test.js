import test from 'node:test';
import assert from 'node:assert/strict';
import {normalizeSong,parseSongLyrics,songPartLabels,songSteps,validateSongs} from '../dist/songs.js';
import {songSlides,safeProjection} from '../dist/core.js';
import {cleanDrafts,emptyDrafts,contentEntry} from '../dist/personal-library.js';
const sample=()=>({id:'song-test',title:'Canto ficticio de prueba',sections:[
  {id:'v1',type:'verse',text:'Primer verso ficticio.\nSegunda línea.'},
  {id:'c',type:'chorus',text:'Un coro original para probar el programa.'},
  {id:'v2',type:'verse',text:'Segundo verso ficticio.'}
],order:['v1','c','v2','c']});

test('migra cantos anteriores sin perder texto, líneas ni identificador',()=>{
  const old={id:'old',title:'Mi canto',lyrics:'Una línea\nOtra línea\n\nUna segunda parte'};
  const song=normalizeSong(old);
  assert.equal(song.id,old.id);assert.equal(song.lyrics,old.lyrics);assert.equal(song.sections.length,2);
  assert.deepEqual(song.order,['part-1','part-2']);assert.deepEqual(songPartLabels(song.sections),['Verso 1','Verso 2']);
  assert.deepEqual(normalizeSong(old).sections,song.sections);assert.equal(old.sections,undefined);
});
test('al pegar letras reconoce etiquetas y separadores sin proyectar sus encabezados',()=>{
  const text='[Verso 1]\r\nPrimera línea.\r\nOtra línea.\r\n\r\nCoro:\r\n\r\nLetra del coro.\r\n\r\nPre-coro\r\nTexto del precoro.\r\n\r\nPuente\r\nTexto del puente.';
  const sections=parseSongLyrics(text);
  assert.deepEqual(sections.map(part=>part.type),['verse','chorus','prechorus','bridge']);
  assert.equal(sections[0].text,'Primera línea.\nOtra línea.');assert.equal(sections[1].text,'Letra del coro.');
  assert.equal(parseSongLyrics('Una letra\n\nCoro').at(-1).text,'Coro');
});
test('el orden repite una misma parte y actualizar el coro cambia todas sus apariciones',()=>{
  const song=normalizeSong(sample());
  assert.deepEqual(songSteps(song).map(part=>part.label),['Verso 1','Coro','Verso 2','Coro']);
  const slides=songSlides(song);assert.equal(slides.length,4);assert.equal(slides[1].songSectionId,slides[3].songSectionId);assert.equal(slides[1].text,slides[3].text);
  song.sections[1].text='El coro se corrigió una sola vez.';
  const changed=songSlides(song);assert.equal(changed[1].text,changed[3].text);assert.equal(changed[3].text,song.sections[1].text);
  assert.ok(changed.every(slide=>slide.reference===song.title));
});
test('una parte larga conserva sus palabras y sus páginas antes de pasar a la siguiente parte',()=>{
  const song=sample();song.sections[0].text=('Texto largo de prueba que debe mantenerse completo. ').repeat(30);
  const slides=songSlides(song),first=slides.filter(slide=>slide.songStep===0);
  assert.ok(first.length>1);assert.equal(first.map(slide=>slide.text).join(' '),song.sections[0].text.trim());
  assert.deepEqual(first.map(slide=>slide.songPartPage),first.map((_,index)=>index));assert.ok(first.every(slide=>slide.songPartPages===first.length));
  assert.equal(slides[first.length].songPartLabel,'Coro');
  const restored=safeProjection({slides,index:first.length,origin:{kind:'song',songId:song.id}});
  assert.equal(restored.slides[restored.index].songSectionId,'c');assert.equal(restored.slides[restored.index].songStep,1);
});
test('respaldo nuevo conserva partes y repeticiones, y se siguen admitiendo respaldos anteriores',()=>{
  const song=normalizeSong(sample());const recovered=validateSongs(JSON.parse(JSON.stringify({schema:'icthus-cantos-v2',songs:[song]})))[0];
  assert.notEqual(recovered.id,song.id);assert.deepEqual(recovered.sections,song.sections);assert.deepEqual(recovered.order,song.order);
  const old=validateSongs({schema:'ap-cantos-v1',songs:[{title:'Anterior',lyrics:'Parte A\n\nParte B'}]})[0];assert.equal(old.sections.length,2);
});
test('rechaza tipos, referencias, partes vacías y estructuras que exceden los límites',()=>{
  const empty=sample();empty.sections[1].text='  ';assert.throws(()=>normalizeSong(empty),/letra de Coro/);
  const repeated=sample();repeated.sections[1].id='v1';assert.throws(()=>normalizeSong(repeated),/repetidas/);
  const missing=sample();missing.order=['missing'];assert.throws(()=>normalizeSong(missing),/orden/);
  const wrong=sample();wrong.sections[0].type='script';assert.throws(()=>normalizeSong(wrong),/formato/);
  const many=sample();many.order=Array(201).fill('c');assert.throws(()=>normalizeSong(many),/200/);
  const long=sample();long.sections[0].text='A'.repeat(50001);assert.throws(()=>normalizeSong(long),/50,000/);
  const huge=sample();huge.sections[1].text='Palabra de prueba. '.repeat(1000);huge.order=Array(200).fill('c');assert.throws(()=>songSlides(huge),/2,000/);
});
test('los borradores conservan tipos, partes sin terminar, orden y texto pendiente de separar',()=>{
  const draft={songId:null,title:'Sin terminar',lyrics:'  Línea sin terminar\n\n',sections:[{id:'v',type:'verse',text:'  Línea sin terminar'},{id:'c',type:'chorus',text:''}],order:['v','c','v'],pasteText:'Letra pendiente\nOtra línea',updatedAt:100};
  const source={...emptyDrafts(),songs:{new:draft}};
  assert.deepEqual(cleanDrafts(JSON.parse(JSON.stringify(source))).songs.new,draft);
  const automatic={...draft,order:null};assert.equal(cleanDrafts({...source,songs:{new:automatic}}).songs.new.order,null);
});
test('el historial conserva la identidad de la parte y la página para recuperarlas tras editar el canto',()=>{
  const song=normalizeSong(sample()),slide=songSlides(song)[3];
  const entry=contentEntry(slide,{kind:'song',songId:song.id},3,100);
  assert.equal(entry.source.sectionId,'c');assert.equal(entry.source.step,3);assert.equal(entry.source.page,0);assert.equal(entry.slide.songPartLabel,'Coro');
});
