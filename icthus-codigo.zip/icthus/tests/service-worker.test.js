import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';

const source=readFileSync(new URL('../dist/sw.js',import.meta.url),'utf8');
const origin='https://proyeccion.example';

function worker({cached,network,scope=origin+'/'}={}) {
  const listeners={};
  const cache={match:async()=>{if(!cached)return;const response=cached.clone();if(cached.redirected)Object.defineProperty(response,'redirected',{value:true});return response;}};
  runInNewContext(source,{
    self:{location:{origin},registration:{scope},addEventListener:(name,handler)=>listeners[name]=handler},
    caches:{open:async()=>cache},URL,Response,fetch:async request=>network?network(request):new Response('network')
  });
  return async(path,{mode='navigate',redirect='manual'}={})=>{
    let answer;
    listeners.fetch({request:{url:origin+path,method:'GET',mode,redirect},respondWith:promise=>answer=promise});
    return answer;
  };
}

function redirectedHtml(){
  // Una respuesta final guardada tras seguir /projection.html → /projection.
  const response=new Response('<main>Proyección lista</main>',{headers:{'Content-Type':'text/html; charset=utf-8'}});
  Object.defineProperty(response,'redirected',{value:true});
  return response;
}

test('una navegación puede abrir el HTML guardado después de una redirección del alojamiento',async()=>{
  const response=await worker({cached:redirectedHtml()})('/projection.html');
  // Chrome rechaza redirected=true con redirect=manual y presenta ERR_FAILED.
  assert.equal(response.redirected,false);
  assert.equal(response.status,200);
  assert.equal(response.headers.get('Content-Type'),'text/html; charset=utf-8');
  assert.equal(await response.text(),'<main>Proyección lista</main>');
});

test('las redirecciones HTTP de la red se entregan al navegador sin sustituirlas',async()=>{
  const response=await worker({network:()=>Response.redirect(origin+'/projection',307)})('/projection.html');
  assert.equal(response.status,307);
  assert.equal(response.headers.get('Location'),origin+'/projection');
});

test('el modo sin conexión encuentra también la dirección de proyección sin .html',async()=>{
  const response=await worker({cached:redirectedHtml()})('/projection');
  assert.ok(response,'La dirección pública canónica también debe usar la copia local.');
  assert.equal(response.redirected,false);
  assert.equal(await response.text(),'<main>Proyección lista</main>');
});

test('las rutas y el inicio instalado funcionan bajo una subcarpeta de GitHub Pages',async()=>{
  const get=worker({cached:new Response('local'),scope:origin+'/icthus/'});
  for(const path of ['/icthus/?source=installed','/icthus/projection.html','/icthus/backup.js','/icthus/app-icons/icthus-512.png'])assert.equal(await (await get(path)).text(),'local');
  assert.equal(await get('/another/projection.html'),undefined);
});

test('actualizar una copia conserva los cachés de otros proyectos del mismo dominio',async()=>{
  const listeners={},deleted=[];
  runInNewContext(source,{
    self:{location:{origin},registration:{scope:origin+'/icthus/'},addEventListener:(name,fn)=>listeners[name]=fn,clients:{claim:async()=>{},matchAll:async()=>[]}},
    caches:{keys:async()=>['icthus-%2Ficthus%2F-old','icthus-%2Fother%2F-old','ap-proyeccion-v4'],delete:async name=>deleted.push(name)},URL,Response
  });
  let ready;listeners.activate({waitUntil:value=>ready=value});await ready;
  assert.deepEqual(deleted,['icthus-%2Ficthus%2F-old']);
});
