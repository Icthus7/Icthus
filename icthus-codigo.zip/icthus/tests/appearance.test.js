import test from 'node:test';
import assert from 'node:assert/strict';
import {BACKGROUNDS,DEFAULT_TEXT,normalizeAppearance,slideContentKey,transitionPlan} from '../dist/appearance.js';
import {safeProjection} from '../dist/core.js';
import {saveBackgroundImage} from '../dist/background-media.js';

test('migra ajustes anteriores conservando el fondo y el tamaño elegidos',()=>{
  const result=normalizeAppearance({theme:'ocean',fontSize:72});
  assert.equal(result.background.theme,'ocean');assert.equal(result.fontSize,72);assert.equal(result.textStyle.fontSize,72);assert.equal(result.transition.type,'fade');
  assert.equal(BACKGROUNDS.length,8);assert.equal(new Set(BACKGROUNDS.map(bg=>bg.id)).size,8);
});
test('conserva todos los parámetros de texto y permite un rango mayor de tamaños',()=>{
  const textStyle={...DEFAULT_TEXT,fontFamily:'modern',fontSize:128,color:'#FAD8A5',bold:true,italic:true,align:'left',vertical:'bottom',lineHeight:1.8,letterSpacing:.04,margin:12,shadow:'strong',outline:2,autoFit:false,referenceScale:.5,showVersion:false};
  const actual=normalizeAppearance({textStyle}).textStyle;
  assert.deepEqual(actual,{...textStyle,color:'#fad8a5'});
  assert.equal(normalizeAppearance({fontSize:999}).fontSize,160);assert.equal(normalizeAppearance({fontSize:-1}).fontSize,20);
});
test('los mensajes de proyección preservan estilo, fondo y transición entre ventanas',()=>{
  const payload={slides:[{text:'Mensaje de prueba',reference:'Aviso',version:''}],index:0,textStyle:{fontSize:100,bold:true,showReference:false},background:{mode:'solid',color:'#123456',overlay:25},transition:{type:'slide',duration:800}};
  const result=safeProjection(payload);
  assert.equal(result.textStyle.fontSize,100);assert.equal(result.textStyle.bold,true);assert.equal(result.textStyle.showReference,false);assert.equal(result.background.color,'#123456');assert.equal(result.transition.duration,800);
});
test('valida valores visuales y referencias de imagen sin aceptar CSS o URLs arbitrarias',()=>{
  const value=normalizeAppearance({textStyle:{fontFamily:'url(bad)',color:'red;display:none',lineHeight:Infinity,letterSpacing:3,margin:90,outline:-4},background:{mode:'image',imageId:'https://example.com/photo.jpg',color:'javascript:bad'},transition:{type:'unknown',duration:99999}});
  assert.equal(value.textStyle.fontFamily,'classic');assert.equal(value.textStyle.color,'#ffffff');assert.equal(value.textStyle.lineHeight,1.45);assert.equal(value.textStyle.margin,20);assert.equal(value.textStyle.outline,0);assert.equal(value.background.mode,'theme');assert.equal(value.transition.type,'fade');assert.equal(value.transition.duration,1500);
});
test('los ajustes son recuperables sin incluir los píxeles de la imagen en cada mensaje',()=>{
  const before=normalizeAppearance({background:{mode:'image',imageId:'media-12345678',overlay:40},textStyle:{fontSize:96,fontFamily:'clean'}});
  const after=normalizeAppearance(JSON.parse(JSON.stringify(before)));
  assert.deepEqual(after,before);assert.equal(after.background.imageId,'media-12345678');assert.ok(!JSON.stringify(after).includes('base64'));
});
test('los mensajes repetidos con el mismo contenido tienen la misma identidad visual',()=>{
  const slide={text:'Texto',reference:'Referencia',version:'Edición'};
  assert.equal(slideContentKey(slide),slideContentKey({...slide}));assert.notEqual(slideContentKey(slide),slideContentKey({...slide,text:'Siguiente'}));assert.notEqual(slideContentKey(slide),slideContentKey(slide,true));
  assert.equal(transitionPlan({previous:true,changed:false}),null);
});
test('la pantalla negra, el movimiento reducido y el corte omiten la animación',()=>{
  assert.equal(transitionPlan({previous:true,changed:true,black:true}),null);
  assert.equal(transitionPlan({previous:true,changed:true,reduceMotion:true}),null);
  assert.equal(transitionPlan({previous:true,changed:true,transition:{type:'none',duration:800}}),null);
  const plan=transitionPlan({previous:true,changed:true,transition:{type:'fade',duration:650}});assert.equal(plan.duration,650);assert.equal(plan.incoming[0].opacity,0);assert.equal(plan.incoming[1].opacity,1);
});
test('rechaza archivos de fondo incompatibles o demasiado grandes antes de decodificarlos',async()=>{
  await assert.rejects(saveBackgroundImage({type:'image/gif',size:100}),/JPG, PNG o WebP/);
  await assert.rejects(saveBackgroundImage({type:'image/jpeg',size:16000000}),/15 MB/);
});
