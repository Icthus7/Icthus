import test from 'node:test';
import assert from 'node:assert/strict';
import {fetchBibleJson,parseBibleJson,MAX_BIBLE_JSON_BYTES} from '../dist/bible-download.js';
const link='https://example.test/biblia.json';

test('descarga JSON por HTTPS sin cookies ni referencia y conserva caracteres UTF-8',async()=>{
  const bytes=new TextEncoder().encode('\uFEFF{"title":"Texto ficticio: canción, ñ"}');
  const data=await fetchBibleJson(link,{fetchImpl:async(url,options)=>{
    assert.equal(url,link);assert.equal(options.credentials,'omit');assert.equal(options.referrerPolicy,'no-referrer');
    return new Response(new ReadableStream({start(controller){for(const byte of bytes)controller.enqueue(new Uint8Array([byte]));controller.close();}}));
  }});
  assert.equal(data.title,'Texto ficticio: canción, ñ');
});
test('rechaza páginas HTML, enlaces incompletos, HTTP y credenciales en el enlace',async()=>{
  assert.throws(()=>parseBibleJson('<html>Página, no archivo</html>'),/enlace directo/);
  for(const value of ['biblia.json','http://example.test/b.json','javascript:alert(1)','https://user:secret@example.test/b.json'])await assert.rejects(fetchBibleJson(value,{fetchImpl:()=>{assert.fail('No debe iniciar la descarga.');}}),/https|HTTPS/);
});
test('informa fallos de red y respuestas HTTP sin sustituir la Biblia activa',async()=>{
  await assert.rejects(fetchBibleJson(link,{fetchImpl:async()=>{throw new TypeError('Network error');}}),/impórtalo como archivo/);
  await assert.rejects(fetchBibleJson(link,{fetchImpl:async()=>new Response('Missing',{status:404})}),/HTTP 404/);
});
test('limita el tamaño declarado y el tamaño real de una descarga sin cabecera',async()=>{
  await assert.rejects(fetchBibleJson(link,{fetchImpl:async()=>new Response('{}',{headers:{'content-length':String(MAX_BIBLE_JSON_BYTES+1)}})}),/15 MB/);
  await assert.rejects(fetchBibleJson(link,{fetchImpl:async()=>new Response(new Uint8Array(MAX_BIBLE_JSON_BYTES+1))}),/15 MB/);
});
test('distingue una cancelación de un tiempo de espera agotado',async()=>{
  const pending=async(_url,{signal})=>new Promise((resolve,reject)=>{if(signal.aborted)reject(new Error('Aborted'));else signal.addEventListener('abort',()=>reject(new Error('Aborted')),{once:true});});
  await assert.rejects(fetchBibleJson(link,{fetchImpl:pending,timeoutMs:5}),/tardó demasiado/);
  const controller=new AbortController();controller.abort();
  await assert.rejects(fetchBibleJson(link,{fetchImpl:pending,signal:controller.signal}),/cancelada/);
});
