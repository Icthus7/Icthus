import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {runInNewContext} from 'node:vm';
const source=readFileSync(new URL('../dist/install.js',import.meta.url),'utf8').replace('export function','function')+'\nsetupInstallation(elements);';
function fixture(){
  const events={},clicks={},elements=Object.fromEntries(['button','status','help','hostedNotice','hostedDownload'].map(key=>[key,{hidden:false,disabled:false,textContent:'',addEventListener:(name,fn)=>clicks[name]=fn}]));
  runInNewContext(source,{window:{addEventListener:(name,fn)=>events[name]=fn,matchMedia:()=>({matches:false,addEventListener(){}})},location:{hostname:'iglesia.example'},elements});
  return {events,elements,clicks};
}
test('sin aviso nativo se muestra el menú y no se inventa una instalación',()=>{
  const {elements}=fixture();assert.equal(elements.button.disabled,true);assert.match(elements.status.textContent,/menú/);assert.equal(elements.help.hidden,false);assert.equal(elements.hostedDownload.hidden,true);
});
test('aceptar el aviso todavía espera la confirmación de instalación del navegador',async()=>{
  const {events,elements,clicks}=fixture();let prevented=false,prompted=false;
  events.beforeinstallprompt({preventDefault(){prevented=true;},async prompt(){prompted=true;},userChoice:Promise.resolve({outcome:'accepted'})});
  assert.equal(prevented,true);assert.equal(elements.button.disabled,false);await clicks.click();assert.equal(prompted,true);assert.match(elements.status.textContent,/Completa/);
  events.appinstalled();assert.match(elements.status.textContent,/se instaló/);assert.equal(elements.help.hidden,true);
});
