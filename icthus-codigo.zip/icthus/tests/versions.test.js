import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {BOOKS,verseSlides,safeProjection} from '../dist/core.js';
import {importBibleData} from '../dist/versions.js';
const base=JSON.parse(readFileSync(new URL('../dist/data/rv1909.json',import.meta.url)));
// Datos ficticios para validar el formato; no contienen texto de RVR1960 ni TLA.
const fixture=id=>({id,books:Object.fromEntries(Object.entries(base.books).map(([book,chapters])=>[book,chapters.map(chapter=>chapter.map(()=>'Texto ficticio para una prueba de software.'))]))});
const snapshotFixture=()=>({local_abbreviation:'RVR1960',local_title:'Edición de prueba 1960',copyright:{text:'Aviso de derechos ficticio.',html:'<script>Este HTML nunca se utiliza</script>'},books:BOOKS.map(book=>({
  usfm:book.id,human:book.name,chapters:base.books[book.id].map((verses,ci)=>({
    usfm:`${book.id}.${ci+1}`,items:[{type:'heading1',verse_numbers:[],lines:['Título que no forma parte del versículo.']},...verses.map((_,vi)=>({type:'verse',verse_numbers:[vi+1],lines:[`Texto ficticio ${book.id} ${ci+1} ${vi+1}.`]}))]
  }))
}))});

test('importa un archivo estructurado completo sin sustituir ni inventar su texto',()=>{
  const source=fixture('TLA'),bible=importBibleData(source,'TLA');
  assert.equal(bible.id,'TLA');assert.equal(bible.translation,'Traducción en Lenguaje Actual');assert.equal(Object.keys(bible.books).length,66);assert.equal(bible.verseCount,31084);assert.equal(bible.books.JHN[2][15],source.books.JHN[2][15]);
});
test('acepta el formato de libros, capítulos y versículos numerados de Scrollmapper',()=>{
  const source=fixture('RVR1960');
  const data={id:'RVR1960',books:BOOKS.map(book=>({
    name:book.name,
    chapters:source.books[book.id].map((chapter,index)=>({
      chapter:index+1,
      verses:chapter.map((text,vi)=>({verse:vi+1,text}))
    }))
  }))};
  assert.equal(importBibleData(data,'RVR1960').id,'RVR1960');
});
test('rechaza etiquetar RV1909 como RVR1960 o TLA',()=>{
  assert.throws(()=>importBibleData(base,'RVR1960'),/no coincide/);
  assert.throws(()=>importBibleData({id:'TLA',books:base.books},'RVR1960'),/no coincide/);
});
test('Snapshots conserva referencias, líneas, fragmentos y derechos sin duplicar capítulos idénticos',()=>{
  const data=snapshotFixture(),genesis=data.books[0].chapters[0];
  genesis.items[1].lines=['Primera línea ficticia.','Segunda línea ficticia.'];
  genesis.items.splice(2,0,{type:'heading2',verse_numbers:[],lines:['Otro título.']},{type:'verse',verse_numbers:[1],lines:['Continuación ficticia.']});
  const obadiah=data.books.find(book=>book.usfm==='OBA');obadiah.chapters.push(structuredClone(obadiah.chapters[0]));
  const bible=importBibleData(data,'RVR1960');
  assert.equal(bible.books.GEN[0][0],'Primera línea ficticia.\nSegunda línea ficticia.\nContinuación ficticia.');
  assert.equal(bible.books.GEN[0][1],'Texto ficticio GEN 1 2.');
  assert.equal(bible.books.OBA.length,1);assert.equal(bible.verseCount,31084);assert.equal(bible.copyright,'Aviso de derechos ficticio.');
  assert.equal(data.books.find(book=>book.usfm==='OBA').chapters.length,2);
});
test('Snapshots detecta la versión en sus metadatos y rechaza etiquetas contradictorias',()=>{
  const data=snapshotFixture();assert.throws(()=>importBibleData(data,'TLA'),/no coincide/);
  data.id='TLA';assert.throws(()=>importBibleData(data,'RVR1960'),/contradictorias/);
});
test('Snapshots no renumera versículos combinados, huecos ni fragmentos fuera de orden',()=>{
  const combined=snapshotFixture();combined.books[0].chapters[0].items[1].verse_numbers=[1,2];assert.throws(()=>importBibleData(combined,'RVR1960'),/combinados/);
  const gap=snapshotFixture();gap.books[0].chapters[0].items[2].verse_numbers=[3];assert.throws(()=>importBibleData(gap,'RVR1960'),/no es consecutiva/);
  const unordered=snapshotFixture();unordered.books[0].chapters[0].items.push({type:'verse',verse_numbers:[1],lines:['Fragmento fuera de orden.']});assert.throws(()=>importBibleData(unordered,'RVR1960'),/no es consecutiva/);
});
test('Snapshots rechaza capítulos repetidos con cambios y referencias de otro libro',()=>{
  const different=snapshotFixture(),book=different.books.find(book=>book.usfm==='OBA');
  const copy=structuredClone(book.chapters[0]);copy.items[1].lines=['Otro texto ficticio.'];book.chapters.push(copy);assert.throws(()=>importBibleData(different,'RVR1960'),/contenido diferente/);
  const wrong=snapshotFixture();wrong.books[0].chapters[0].usfm='EXO.1';assert.throws(()=>importBibleData(wrong,'RVR1960'),/referencia/);
});
test('rechaza archivos incompletos, capítulos faltantes y versículos vacíos',()=>{
  const incomplete=fixture('TLA');delete incomplete.books.GEN;assert.throws(()=>importBibleData(incomplete,'TLA'),/66 libros/);
  const chapters=fixture('TLA');chapters.books.GEN.pop();assert.throws(()=>importBibleData(chapters,'TLA'),/50 capítulos/);
  const blank=fixture('TLA');blank.books.GEN[0][0]='';assert.throws(()=>importBibleData(blank,'TLA'),/vacíos/);
});
test('la diapositiva y el estado recuperado preservan la versión seleccionada',()=>{
  const slides=verseSlides([{reference:'Juan 3:16',text:'Texto ficticio de prueba.'}],'Traducción en Lenguaje Actual');
  assert.equal(slides[0].version,'Traducción en Lenguaje Actual');
  const restored=safeProjection({slides,index:0,origin:{kind:'bible',versionId:'TLA'}});
  assert.equal(restored.origin.versionId,'TLA');assert.equal(restored.slides[0].version,'Traducción en Lenguaje Actual');
});
