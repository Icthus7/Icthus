"""Convierte el VPL de eBible RV1909. Uso: python3 scripts/import-bible.py archivo.zip"""
import hashlib
import json
from pathlib import Path
import re
import sys
from zipfile import ZipFile

root = Path(__file__).resolve().parent.parent
source = Path(sys.argv[1])
with ZipFile(source) as archive:
    text = archive.read('spaRV1909_vpl.txt').decode('utf-8-sig')
aliases = {'SOL':'SNG','EZE':'EZK','JOE':'JOL','NAH':'NAM','MAR':'MRK','JOH':'JHN','PHI':'PHP','JAM':'JAS','1JO':'1JN','2JO':'2JN','3JO':'3JN'}
books = {}
for line in text.splitlines():
    if not line.strip():
        continue
    match = re.fullmatch(r'(\S+) (\d+):(\d+) (.*)', line)
    if not match:
        raise ValueError(f'Línea no reconocida: {line[:80]}')
    code, chapter, verse, content = match.groups()
    chapter, verse = int(chapter), int(verse)
    chapters = books.setdefault(aliases.get(code, code), [])
    while len(chapters) < chapter:
        chapters.append([])
    if len(chapters[chapter - 1]) != verse - 1:
        raise ValueError(f'Numeración discontinua en {code} {chapter}:{verse}')
    chapters[chapter - 1].append(content)
removed = 0
for chapters in books.values():
    for chapter in chapters:
        while chapter and not chapter[-1].strip():
            chapter.pop()
            removed += 1
        if not all(verse.strip() for verse in chapter):
            raise ValueError('Un registro vacío intermedio requiere revisión manual.')
count = sum(len(chapter) for chapters in books.values() for chapter in chapters)
if len(books) != 66 or count != 31084 or removed != 18:
    raise ValueError('La fuente cambió. Revisa sus libros y versículos antes de reemplazar los datos.')
data = {'translation':'Reina-Valera 1909', 'source':'https://ebible.org/Scriptures/spaRV1909_vpl.zip', 'books':books, 'sourceNotes':'Se omiten 18 registros de relleno vacíos al final de capítulos del VPL. Se conserva el texto y la numeración de la fuente.'}
(root / 'dist/data/rv1909.json').write_text(json.dumps(data, ensure_ascii=False, separators=(',',':')), encoding='utf-8')
print({'libros':len(books), 'versiculos_con_texto':count, 'relleno_omitido':removed, 'sha256_fuente':hashlib.sha256(source.read_bytes()).hexdigest()})
