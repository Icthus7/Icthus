"""Empaqueta solo el programa estático para alojamiento independiente."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parent.parent
output=root/'dist'/'icthus-independiente.zip'
with ZipFile(output,'w',ZIP_DEFLATED,compresslevel=9) as archive:
    for path in sorted((root/'dist').rglob('*')):
        if not path.is_file() or path==output:continue
        relative=path.relative_to(root/'dist')
        if any(part.startswith('.') for part in relative.parts):continue
        if path.suffix=='.zip' and path.name!='icthus-codigo.zip':continue
        archive.write(path,relative.as_posix())
    archive.writestr('.nojekyll','')
    archive.write(root/'docs'/'INSTALAR-ICTHUS.md','LEEME-ICTHUS.md')
print(f'Paquete independiente: {output.name} ({output.stat().st_size:,} bytes)')
