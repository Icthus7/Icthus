"""Rasteriza el símbolo geométrico original de Icthus para Chrome."""
from pathlib import Path
from PIL import Image, ImageDraw
root=Path(__file__).resolve().parent.parent
folder=root/'dist'/'app-icons';folder.mkdir(exist_ok=True)
scale=32
im=Image.new('RGBA',(64*scale,64*scale),(0,0,0,0));draw=ImageDraw.Draw(im)
draw.rounded_rectangle((0,0,64*scale-1,64*scale-1),radius=17*scale,fill='#8770fa')
def cubic(a,b,c,d):
    return [((1-t)**3*a[0]+3*(1-t)**2*t*b[0]+3*(1-t)*t*t*c[0]+t**3*d[0],(1-t)**3*a[1]+3*(1-t)**2*t*b[1]+3*(1-t)*t*t*c[1]+t**3*d[1]) for t in (i/160 for i in range(161))]
paths=[cubic((11,32),(21,17),(34,17),(53,32))+cubic((53,32),(34,47),(21,47),(11,32)),[(42,23),(53,13)],[(42,41),(53,51)]]
width=round(3.5*scale)
for path in paths:
    points=[(round(x*scale),round(y*scale)) for x,y in path]
    draw.line(points,fill='white',width=width,joint='curve')
    for x,y in (points[0],points[-1]):draw.ellipse((x-width/2,y-width/2,x+width/2,y+width/2),fill='white')
for size in (192,512):im.resize((size,size),Image.Resampling.LANCZOS).save(folder/f'icthus-{size}.png')
print('Iconos de Icthus preparados: 192 y 512 píxeles.')
