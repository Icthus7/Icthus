"""Prepara un ZIP para estudiar el código, sin identidad del sitio ni archivos de Git."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parent.parent
output = root / 'dist' / 'icthus-codigo.zip'
files = [root / 'README.md', root / 'package.json']
for folder in ('dist', 'tests', 'scripts', 'docs'):
    files.extend(path for path in (root / folder).rglob('*') if path.is_file() and path.suffix != '.zip' and '__pycache__' not in path.parts)
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=9) as archive:
    for path in files:
        archive.write(path, 'icthus/' + path.relative_to(root).as_posix())
(root / 'dist' / 'aplicacion-de-proyeccion-codigo.zip').unlink(missing_ok=True)
print(f'Código preparado: {output.name} ({output.stat().st_size:,} bytes)')
